# hard-on-start

Simply sets the game to hard when the server starts (and restarts).

## Developing

To make a new release, just push a commit with a message starting with `release: ` and the rest of the message will be used as the release title.
