# name_formatting_station
 
A datapack that adds the ability for players to format item names in survival, along with giving the ability to add lore to items.


You can start by accessing the menu using: "/trigger FormatName"

 - Hold a named item in your mainhand to format it.
 - Formatting an item name costs 1 xp level by default.
 - You can change the Style, Color, and Font of an item name.
 - You can merge together item names to mixed format names.
 - You can add and delete lore from items.
 

You can access the admin configurations by using: /function name_formatting:admin
