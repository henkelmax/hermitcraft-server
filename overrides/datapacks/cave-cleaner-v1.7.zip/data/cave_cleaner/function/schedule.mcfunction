# Slow schedule loop to find mobs

schedule function cave_cleaner:schedule 10t

#> Handle triggers
execute as @a[gamemode=spectator,scores={cave_cleaner=1..}] at @s run function cave_cleaner:trigger_cave_cleaner
execute as @a[gamemode=spectator,scores={cave_glow=1..}] at @s run function cave_cleaner:trigger_cave_glow

#> Resets
# Ensure triggers are enabled for spectators and reset for non-spectators
scoreboard players enable @a[gamemode=spectator] cave_cleaner
scoreboard players enable @a[gamemode=spectator] cave_glow
scoreboard players reset @a[gamemode=!spectator,scores={cave_cleaner=0..}] cave_cleaner
scoreboard players reset @a[gamemode=!spectator,scores={cave_glow=0..}] cave_glow
